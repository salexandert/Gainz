# For CPAs

This file is a concise orientation note for a tax professional reviewing a Gainz packet.
Gainz is documentation support only. It does not provide legal, financial, accounting, filing, or tax advice.

## Packet Status

- Status: FILING-READY REVIEW PACKET
- Readiness: Ready for review
- Summary: No unresolved blocker groups are open.
- Next action: Generate the audit packet, then review exported files against source records.
- Transactions: 8
- Assets: BTC, ETH

## Suggested Review Order

1. `PACKET_STATUS.md` for readiness, blockers, warnings, and evidence counts.
2. `01_reports/reconciliation_work_order.csv` for the itemized unresolved work queue.
3. `01_reports/tax_filing_alignment.csv` for calculated totals compared with user-entered filed totals.
4. `01_reports/form_8949_totals.csv` and the Form 8949 detail CSVs for proceeds, basis, and gain/loss.
5. `01_reports/holdings_reconciliation.csv` and `01_reports/current_holdings_lots.csv` for holdings explanation.
6. `03_manifests/evidence_manifest.csv` for copied files, reference-only evidence, missing paths, and hashes.

## Evidence Handling

- Copied transaction source files: 3
- Copied tax evidence files: 0
- Reference-only tax evidence records: 2
- Missing tax evidence file paths: 0

Reference-only tax evidence records list a local path or label but do not include the file in this packet.
Copied files are present in `02_source_files/` and are listed with hashes in the evidence manifest.

## Items That Commonly Need Professional Judgment

- Whether sends, receives, lost assets, transfers, conversions, and missing records were classified correctly.
- Whether imported CSVs represent complete exchange, wallet, and brokerage history for the reviewed years.
- Whether the user's filed totals and payment evidence align with generated Gainz totals.
- Whether unresolved blockers make this packet draft-only.
