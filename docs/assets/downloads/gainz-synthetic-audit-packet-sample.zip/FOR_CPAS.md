# For CPAs

This file is a concise orientation note for a tax professional reviewing a Gainz packet.
Gainz is documentation support only. It does not provide legal, financial, accounting, filing, or tax advice.

## Packet Status

- Status: RECONCILIATION COMPLETE - PROFESSIONAL FILING REVIEW REQUIRED
- Readiness: Ready for review
- Summary: No unresolved blocker groups are open.
- Next action: Generate the audit packet, then review exported files against source records.
- Transactions: 3
- Assets: BCH

## Suggested Review Order

1. `PACKET_STATUS.md` for readiness, blockers, warnings, and evidence counts.
2. `01_reports/reconciliation_work_order.csv` for the itemized unresolved work queue.
3. `01_reports/cpa_resolution_workpapers.csv` for separately documented event, proceeds, basis, evidence, and reviewer fields.
4. `01_reports/import_economics.csv` for source gross values, fees, and net tax amounts.
5. `01_reports/unknown_gap_memos.md` for documented unknowns, user notes, candidate explanations, and CPA questions.
6. `01_reports/tax_filing_alignment.csv` for calculated totals compared with user-entered filed totals.
7. `01_reports/form_8949_totals.csv` and the Form 8949 detail CSVs for proceeds, basis, and gain/loss.
8. `01_reports/holdings_reconciliation.csv` and `01_reports/current_holdings_lots.csv` for holdings explanation.
9. `03_manifests/evidence_manifest.csv` for copied files, reference-only evidence, missing paths, and hashes.

## Evidence Handling

- Copied transaction source files: 1
- Copied tax evidence files: 0
- Reference-only tax evidence records: 1
- Missing tax evidence file paths: 0

Reference-only tax evidence records list a local path or label but do not include the file in this packet.
Copied files are present in `02_source_files/` and are listed with hashes in the evidence manifest.

## Material Inputs And Assumptions

- **Source fees included for 2 transaction(s)** (Calculation input): Gainz included $5.50 of imported USD fees in proceeds or cost basis. Review 01_reports/import_economics.csv for source gross, fee, and net values.
- **BCH treatment applied under direction recorded by the user** (Applied - reversible): Basis: Conservative $0 basis under recorded professional direction; holding period: Unknown date - recorded short-term assumption; added proceeds $297.00; added basis $0.00; gain/loss effect $297.00. Evidence: Synthetic professional workpaper BCH-2024-01.

## Items That Commonly Need Professional Judgment

- Whether sends, receives, lost assets, transfers, conversions, and missing records were classified correctly.
- Whether imported CSVs represent complete exchange, wallet, and brokerage history for the reviewed years.
- Whether the user's filed totals and payment evidence align with generated Gainz totals.
- Whether unresolved blockers make this packet draft-only.
- Whether a disposition-date valuation supports proceeds or amount realized; it should not be reused as acquisition basis.

## Questions For The Taxpayer

- Can you provide source records for missing acquisition-basis rows listed in `01_reports/reconciliation_work_order.csv`?
- Do holdings discrepancies represent transfers, disposals, losses, gifts, unsupported rows, or missing imports?
- Were filed totals based on another software package, exchange report, CPA adjustment, or manual calculation?
- Which reference-only evidence files should be copied or shared for professional review?
- Are any unresolved review decisions intentionally left for draft discussion rather than filing support?
