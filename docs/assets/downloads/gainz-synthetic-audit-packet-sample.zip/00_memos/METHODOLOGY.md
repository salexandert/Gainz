# Gainz Synthetic Audit Packet Sample

This sample was generated from bundled synthetic demo files. It demonstrates the packet structure only. It is not tax, legal, or financial advice.

Workflow represented:

1. Import demo Cash App, Coinbase, and Coinbase Convert CSV files.
2. Link demo sales to earlier demo acquisition lots using FIFO.
3. Declare demo current holdings so BTC and ETH reconcile.
4. Export Form 8949-style totals, holdings reconciliation, source manifest, and methodology notes.
