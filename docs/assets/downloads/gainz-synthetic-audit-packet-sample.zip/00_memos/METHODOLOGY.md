# Gainz Audit Packet

This packet was generated locally by Gainz.

Gainz links sale records to earlier buy lots according to the user's selected method. Unlinked sells, unexplained sends, and unexplained receives should be reviewed against source records before using generated reports.

Transaction count: 8
Assets: BTC, ETH

This packet is documentation support only. It is not legal, financial, or tax advice.
