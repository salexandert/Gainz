# Gainz Audit Packet

This packet was generated locally by Gainz.

Gainz links sale records to earlier buy lots according to the user's selected method. Unlinked sells, unexplained sends, and unexplained receives should be reviewed against source records before using generated reports.
Imported USD fees are included in disposal proceeds or acquisition cost when the source file provides them. `01_reports/import_economics.csv` shows source gross, fee, and net values.
Any user-recorded professional calculation treatment is item-specific, shown in the professional resolution workpaper, accompanied by a before/after receipt, and reversible in Gainz.

Transaction count: 3
Assets: BCH

This packet is documentation support only. It is not legal, financial, or tax advice.
