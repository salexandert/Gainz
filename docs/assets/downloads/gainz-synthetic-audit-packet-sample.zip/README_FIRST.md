# Read This First

This folder is a Gainz audit packet generated from local transaction records and review decisions.

Packet status: FILING-READY REVIEW PACKET
Readiness summary: No unresolved blocker groups are open.

## Start Here

1. Open `PACKET_STATUS.md` for the exact blocker, warning, and evidence counts.
2. Open `FOR_CPAS.md` for the CPA-facing review order.
3. Open `CPA_HANDOFF.md` for the generation notes.
4. Open `PRIVACY_AND_EVIDENCE_HANDLING.md` before sharing the packet.
5. Review `01_reports/reconciliation_work_order.csv` for the itemized work queue.

## Folder Map

- `01_reports/`: generated workbook, Form 8949-style CSVs, holdings reconciliation, tax evidence inventory, and work order outputs.
- `02_source_files/`: copied transaction source files and explicitly copied tax evidence files.
- `03_manifests/`: evidence manifest, packet inventory, hashes, and JSON summaries.
- `00_memos/`: methodology and draft-status notes.

## Evidence Handling

- Copied transaction source files: 3
- Copied tax evidence files: 0
- Reference-only tax evidence records: 2
- Missing tax evidence file paths: 0

Reference-only evidence is listed for review but is not copied into this packet.

Gainz is documentation support only. It is not legal, financial, accounting, filing, or tax advice.
If sharing this packet with a tax professional, start with `FOR_CPAS.md`.
