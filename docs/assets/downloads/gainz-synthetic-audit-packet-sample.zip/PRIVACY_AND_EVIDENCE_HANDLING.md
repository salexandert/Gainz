# Privacy And Evidence Handling

Gainz is private offline crypto tax reconciliation software. This packet was generated locally on the user's computer.

## Network And Storage Model

- Gainz does not require a hosted account, exchange API sync, wallet sync, or transaction-history upload for this workflow.
- Imported CSVs, saves, exports, audit packets, and evidence references are local files.
- Local files remain on this computer unless the user shares, uploads, syncs, or backs them up through another service.
- The local Gainz password gates the browser UI. It does not encrypt local CSV, XLSX, JSON, Markdown, or packet files.

## Evidence Handling In This Packet

- Copied transaction source files: 3
- Copied tax evidence files: 0
- Reference-only tax evidence records: 2
- Missing tax evidence file paths: 0

Reference only means the local file path or label is listed in the packet, but the file itself is not copied.
Copied means the file is included inside `02_source_files/` and appears in `03_manifests/evidence_manifest.csv` with hashes.
Missing means Gainz had a saved local path for the evidence file, but the file was not present when the packet was generated.

## Before Sharing

- Review `03_manifests/evidence_manifest.csv` for every copied or referenced file.
- Remove any source files or evidence copies that should not be shared.
- Treat this packet like sensitive tax data.
