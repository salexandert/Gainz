# Gainz Reconciliation Work Order

Use this file as a review queue. It is documentation support, not tax, legal, or financial advice.

## 1. Import warning decision

- Status: Open
- Asset: N/A
- Year: N/A
- Date: N/A
- Source file: Current import
- Suspected issue: Synthetic warning: review one demo row before treating the packet as filing-ready.
- Next action: Review the source row. If it should affect holdings or generated reports, fix the CSV mapping, re-import the source, or add a source-backed manual transaction.

## 2. Tax evidence review

- Status: Needs filed totals
- Asset: N/A
- Year: 2024
- Date: N/A
- Source file: N/A
- Suspected issue: Gainz calculated Form 8949-style totals
- Next action: 2024: enter filed proceeds, cost basis, and gain/loss or upload evidence showing no crypto totals apply.
